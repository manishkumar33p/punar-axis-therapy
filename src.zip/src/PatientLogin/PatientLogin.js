import React, {
  useEffect,
  useState,
} from "react";

import {
  useNavigate,
} from "react-router-dom";

import {
  signInPatient,
  getPatientSession,
} from "../auth";

import "./PatientLogin.css";


function PatientLogin() {

  const navigate =
    useNavigate();

  const [
    patientId,
    setPatientId,
  ] = useState("");

  const [
    password,
    setPassword,
  ] = useState("");

  const [
    loading,
    setLoading,
  ] = useState(false);

  const [
    error,
    setError,
  ] = useState("");


  /* =====================================================
     CHECK EXISTING SESSION
     ===================================================== */

  useEffect(() => {

    const session =
      getPatientSession();

    if (
      session?.patient?.patientId
    ) {

      navigate(
        "/patient-dashboard",
        {
          replace: true,
        }
      );
    }

  }, [navigate]);


  /* =====================================================
     LOGIN
     ===================================================== */

  const handleLogin =
    async (event) => {

      event.preventDefault();

      setError("");


      if (!patientId.trim()) {

        setError(
          "Please enter your Patient ID."
        );

        return;
      }


      if (!password.trim()) {

        setError(
          "Please enter your password."
        );

        return;
      }


      setLoading(true);


      try {

        const session =
          await signInPatient(
            patientId,
            password
          );


        if (
          session?.patient?.patientId
        ) {

          navigate(
            "/patient-dashboard",
            {
              replace: true,
            }
          );

        } else {

          throw new Error(
            "Patient dashboard could not be opened."
          );
        }

      } catch (error) {

        console.error(
          "Patient login:",
          error
        );

        setError(
          error?.message ||
          "Incorrect Patient ID or password."
        );

      } finally {

        setLoading(false);
      }
    };


  return (
    <div className="patient-login-page">

      <div className="patient-login-card">

        <div className="patient-login-logo">
          PA
        </div>


        <h1>
          Patient Login
        </h1>


        <p className="patient-login-subtitle">
          Login to access your Punar Axis Therapy
          patient portal.
        </p>


        {error && (
          <div className="patient-login-error">
            {error}
          </div>
        )}


        <form
          onSubmit={handleLogin}
        >

          <div className="patient-login-field">

            <label>
              Patient ID
            </label>

            <input
              type="text"
              value={patientId}
              onChange={(event) =>
                setPatientId(
                  event.target.value.toUpperCase()
                )
              }
              placeholder="PAT-0002"
              disabled={loading}
            />

          </div>


          <div className="patient-login-field">

            <label>
              Password
            </label>

            <input
              type="password"
              value={password}
              onChange={(event) =>
                setPassword(
                  event.target.value
                )
              }
              placeholder="Last 4 digits of mobile"
              maxLength={4}
              inputMode="numeric"
              disabled={loading}
            />

          </div>


          <button
            type="submit"
            disabled={loading}
          >

            {loading
              ? "Logging in..."
              : "Login"}

          </button>

        </form>


        <div className="patient-login-note">

          <strong>
            First-time login
          </strong>

          <span>
            Patient ID is provided by the clinic.
            Password is the last 4 digits of your
            registered mobile number.
          </span>

        </div>

      </div>

    </div>
  );
}

export default PatientLogin;