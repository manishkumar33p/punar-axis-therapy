// src/auth.js

import {
  signInWithEmailAndPassword,
  signOut,
} from "firebase/auth";

import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
  setDoc,
} from "firebase/firestore";

import { auth, db } from "./firebase";

/* =========================================================
   MANAGEMENT LOGIN
========================================================= */

export async function managementLogin(email, password) {
  if (!email || !password) {
    throw new Error("Email and password are required.");
  }

  try {
    const result = await signInWithEmailAndPassword(
      auth,
      email.trim(),
      password
    );

    const user = result.user;

    // Check whether this Firebase user is registered
    // as clinic management/admin.
    const adminRef = doc(db, "admins", user.uid);
    const adminSnapshot = await getDoc(adminRef);

    if (!adminSnapshot.exists()) {
      await signOut(auth);

      throw new Error(
        "This account is not registered as clinic management."
      );
    }

    return user;
  } catch (error) {
    console.error("Management login error:", error);

    throw new Error(
      error?.message || "Management login failed."
    );
  }
}


/* =========================================================
   MANAGEMENT LOGIN ALIAS
   Used by PatientManagement.js
========================================================= */

export async function signInManagement(email, password) {
  return managementLogin(email, password);
}


/* =========================================================
   MANAGEMENT LOGOUT
========================================================= */

export async function managementLogout() {
  try {
    await signOut(auth);
  } catch (error) {
    console.warn("Management logout warning:", error);
  }
}


/* =========================================================
   PATIENT LOGIN HASH
========================================================= */

/*
  Patient login format:

  Patient ID:
  PAT-0002

  Password:
  Last 4 digits of registered mobile number

  Example:

  Mobile:
  9876543210

  Password:
  3210

  We NEVER store the password directly.
  We create a SHA-256 hash of:

  PAT-0002|3210
*/

async function hashLogin(patientId, lastFour) {
  const value =
    `${String(patientId).trim().toUpperCase()}|` +
    `${String(lastFour).replace(/\D/g, "")}`;

  const encoder = new TextEncoder();

  const data = encoder.encode(value);

  const hashBuffer = await crypto.subtle.digest(
    "SHA-256",
    data
  );

  return Array.from(new Uint8Array(hashBuffer))
    .map((byte) =>
      byte.toString(16).padStart(2, "0")
    )
    .join("");
}


/* =========================================================
   CREATE / UPDATE PATIENT PORTAL LOGIN
========================================================= */

/*
  This function is called from PatientManagement.js
  whenever a patient is created/updated.

  Example:

  Patient ID = PAT-0002
  Mobile     = 9876543210

  Login:

  Patient ID = PAT-0002
  Password   = 3210
*/

export async function provisionPatientPortal(patient) {
  if (!patient?.patientId) {
    throw new Error("Patient ID is required.");
  }

  if (!patient?.mobile) {
    throw new Error("Patient mobile number is required.");
  }

  const patientId = String(patient.patientId)
    .trim()
    .toUpperCase();

  const mobile = String(patient.mobile)
    .replace(/\D/g, "");

  if (mobile.length < 4) {
    throw new Error(
      "Patient mobile number must contain at least 4 digits."
    );
  }

  const lastFour = mobile.slice(-4);

  const loginId = await hashLogin(
    patientId,
    lastFour
  );

  const loginRef = doc(
    db,
    "patientLoginIndex",
    loginId
  );

  await setDoc(
    loginRef,
    {
      patientId: patientId,
      updatedAt: new Date().toISOString(),
    },
    {
      merge: true,
    }
  );

  return {
    patientId,
    password: lastFour,
  };
}


/* =========================================================
   PATIENT LOGIN
========================================================= */

export async function signInPatient(
  patientId,
  password
) {
  const id = String(patientId || "")
    .trim()
    .toUpperCase();

  const pass = String(password || "")
    .trim()
    .replace(/\D/g, "");

  if (!id) {
    throw new Error("Please enter Patient ID.");
  }

  if (!pass) {
    throw new Error("Please enter password.");
  }

  if (pass.length !== 4) {
    throw new Error(
      "Password must be the last 4 digits of the registered mobile number."
    );
  }

  if (!id.startsWith("PAT-")) {
    throw new Error(
      "Invalid Patient ID. Example: PAT-0002."
    );
  }

  try {
    /* -----------------------------------------------------
       STEP 1
       Create hash from Patient ID + last 4 digits
    ----------------------------------------------------- */

    const loginId = await hashLogin(id, pass);

    /* -----------------------------------------------------
       STEP 2
       Find login record
    ----------------------------------------------------- */

    const loginRef = doc(
      db,
      "patientLoginIndex",
      loginId
    );

    const loginSnapshot = await getDoc(loginRef);

    if (!loginSnapshot.exists()) {
      throw new Error(
        "Incorrect Patient ID or password."
      );
    }

    const loginData = loginSnapshot.data();

    if (!loginData?.patientId) {
      throw new Error(
        "Patient login record is incomplete."
      );
    }

    const realPatientId = loginData.patientId;

    /* -----------------------------------------------------
       STEP 3
       Load patient profile
    ----------------------------------------------------- */

    const patientRef = doc(
      db,
      "patients",
      realPatientId
    );

    const patientSnapshot = await getDoc(
      patientRef
    );

    if (!patientSnapshot.exists()) {
      throw new Error(
        "Patient login found, but patient profile could not be loaded."
      );
    }

    const patient = {
      id: patientSnapshot.id,
      ...patientSnapshot.data(),
    };

    /* -----------------------------------------------------
       STEP 4
       Load treatment history
    ----------------------------------------------------- */

    let treatmentHistory = [];

    try {
      const treatmentQuery = query(
        collection(db, "patientTreatments"),
        where(
          "patientId",
          "==",
          realPatientId
        )
      );

      const treatmentSnapshot =
        await getDocs(treatmentQuery);

      treatmentHistory =
        treatmentSnapshot.docs.map((item) => ({
          id: item.id,
          ...item.data(),
        }));
    } catch (error) {
      console.warn(
        "Treatment history could not be loaded:",
        error
      );

      treatmentHistory = [];
    }

    /* -----------------------------------------------------
       STEP 5
       Load appointment history
    ----------------------------------------------------- */

    let appointmentHistory = [];

    try {
      const appointmentQuery = query(
        collection(db, "appointments"),
        where(
          "patientId",
          "==",
          realPatientId
        )
      );

      const appointmentSnapshot =
        await getDocs(appointmentQuery);

      appointmentHistory =
        appointmentSnapshot.docs.map((item) => ({
          id: item.id,
          ...item.data(),
        }));
    } catch (error) {
      console.warn(
        "Appointment history could not be loaded:",
        error
      );

      appointmentHistory = [];
    }

    /* -----------------------------------------------------
       STEP 6
       Create patient session
    ----------------------------------------------------- */

    const session = {
      loggedIn: true,

      patient: {
        ...patient,
        patientId: realPatientId,
      },

      treatmentHistory,

      appointmentHistory,

      loggedInAt: new Date().toISOString(),
    };

    /* -----------------------------------------------------
       STEP 7
       Save session locally
    ----------------------------------------------------- */

    localStorage.setItem(
      "patientSession",
      JSON.stringify(session)
    );

    localStorage.setItem(
      "patientData",
      JSON.stringify(session.patient)
    );

    return session;
  } catch (error) {
    console.error(
      "Patient login error:",
      error
    );

    if (
      error?.message ===
      "Incorrect Patient ID or password."
    ) {
      throw error;
    }

    throw new Error(
      error?.message ||
        "Incorrect Patient ID or password."
    );
  }
}


/* =========================================================
   GET PATIENT SESSION
========================================================= */

export function getPatientSession() {
  try {
    const session =
      localStorage.getItem(
        "patientSession"
      );

    if (!session) {
      return null;
    }

    return JSON.parse(session);
  } catch (error) {
    console.error(
      "Patient session error:",
      error
    );

    return null;
  }
}


/* =========================================================
   PATIENT LOGOUT
========================================================= */

export async function signOutPatient() {
  try {
    localStorage.removeItem(
      "patientSession"
    );

    localStorage.removeItem(
      "patientData"
    );
  } catch (error) {
    console.warn(
      "Patient logout warning:",
      error
    );
  }
}


/* =========================================================
   CHANGE PATIENT PASSWORD
========================================================= */

/*
  Patient password is currently:

  Last 4 digits of registered mobile number.

  Therefore patient cannot change it from portal.

  Management can update the mobile number and
  provisionPatientPortal() will create the new login.
*/

export async function changePatientPassword(
  currentPassword,
  newPassword
) {
  throw new Error(
    "Patient password is managed by the clinic. Please contact management to change it."
  );
}